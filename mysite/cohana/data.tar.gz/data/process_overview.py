import math
import json

retented_total = 8256
total = 57077

# a = performed and retent , b = performed but not retent
# c = not performed but retent, d = not performed and not retent
def rho(a, b, c, d):
    n = a+b+c+d
    sigma_x_y = a
    sigma_x = a + b
    sigma_y = a + c
    sigma_xx = a + b
    sigma_x_2 = sigma_x * sigma_x
    sigma_yy = a + c
    sigma_y_2 = sigma_y * sigma_y

    res = (n*sigma_x_y - sigma_x * sigma_y) / \
            math.sqrt((n*sigma_xx-sigma_x_2)*(n*sigma_yy-sigma_y_2))
    return round(res, 3)

def calc_row(row, file_name):
    res = []
    for i in range(1, 8):
        with open('./data/'+file_name.strip()+'-'+str(i)+'.dat') as in_file:
            data = json.load(in_file)
            birth_total = data["result"][0]["measure"]
            a = data["result"][1]["measure"]
            b = birth_total - a
            c = retented_total - a
            d = total - a - b - c
            data_cell = [i-1, row, rho(a,b,c,d)]
            res.append(data_cell)
    return res

def main():
    js = []
    r = 0
    for line in open("./index"):
        js += calc_row(r, line)
        r += 1

    out_data = {'data': js}
    print json.dumps(out_data)

if __name__ == "__main__": main()
